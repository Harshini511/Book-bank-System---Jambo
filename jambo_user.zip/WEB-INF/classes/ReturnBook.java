import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.util.*;


public class ReturnBook extends HttpServlet {

  public void doGet(HttpServletRequest request, HttpServletResponse response){
    try{

    response.setContentType("text/html");
    PrintWriter out = response.getWriter();

    try {
          Class.forName("com.mysql.cj.jdbc.Driver");
      } catch (Exception e) {
          System.out.println(e.toString());
      }

    try(Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/jambodb", "root", "Fireflies#12")){

        if (conn != null) {
            System.out.println("Return - Connected to the database!");
        } else {
            System.out.println("Return - Failed to make connection!");
        }


        String bid = (String)request.getParameter("bid");
        String uid = (String)request.getParameter("uid");
        PreparedStatement pst = conn.prepareStatement("delete from book_user where uid =? and bid =?");
        pst.setString(1,uid);
        pst.setString(2,bid);
        int i = pst.executeUpdate();
        if(i!=0){
          out.println("<h4>Book returned </h4>");
        }

        conn.close();
      }catch(Exception e){System.out.println(e);}
    }catch(Exception e){System.out.println(e);}

}
}
